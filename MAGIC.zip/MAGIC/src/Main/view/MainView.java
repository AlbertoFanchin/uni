package Main.view;

import Main.controller.EnergyController;
import Main.controller.EvocazioneController;
import Main.model.Giocatore;
import Main.model.energies.Energy;
import Main.model.summons.Evocazione;
import javafx.geometry.Pos;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class MainView extends BorderPane {

    private Giocatore player1;
    private Giocatore player2;

    protected VBox player1Energy;
    protected VBox player2Energy;
    protected HBox player1Evocazioni;
    protected  HBox player2Evocazioni;

    public MainView(Giocatore p1, Giocatore p2){
        this.player1 = p1;
        this.player2 = p2;
    }

    private void setupenergies(Giocatore g, VBox pane){
        for (Energy e : g.getEnergie()){
            EnergyPane ep = new EnergyPane(e,pane.getChildren().size());
            pane.getChildren().add(ep);
            ep.addEventHandler(MouseEvent.MOUSE_CLICKED, new EnergyController(ep,g,this));
        }
    }

    private void setupevocazioni(Giocatore g, HBox pane){
        for (Evocazione e :g.getEvocazioni()) {
            EvocazionePane ep = new EvocazionePane(e);
            pane.getChildren().add(ep);
            ep.addEventHandler(MouseEvent.MOUSE_CLICKED, new EvocazioneController(ep,g,this));
        }
    }

    private void setup(){
        player1Energy = new VBox();
        player2Energy = new VBox();
        player1Evocazioni = new HBox();
        player2Evocazioni = new HBox();

        setupenergies(player1, player1Energy);
        setupenergies(player2, player2Energy);
        setupevocazioni(player1, player1Evocazioni);
        setupevocazioni(player2, player2Evocazioni);

        this.setLeft(player1Energy);
        player1Energy.setSpacing(10);
        ((VBox) this.getLeft()).setAlignment(Pos.BOTTOM_CENTER);

        this.setRight(player2Energy);
        player1Energy.setSpacing(10);
        ((VBox) this.getRight()).setAlignment(Pos.TOP_CENTER);

        this.setLeft(player1Evocazioni);
        player1Energy.setSpacing(10);
        ((HBox) this.getBottom()).setAlignment(Pos.BOTTOM_LEFT);

        this.setLeft(player1Energy);
        player1Energy.setSpacing(10);
        ((VBox) this.getTop()).setAlignment(Pos.TOP_RIGHT);


    }

    public void flipPlayers(){
        Giocatore temp = player1;
        player1 = player2;
        player2 = temp;
        this.setup();
    }

    public void refresh(){
        this.setup();
    }

    public boolean isP1(Giocatore g){
        return g == player1;
    }
}
