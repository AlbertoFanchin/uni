package Main.view;

import Main.model.summons.Evocazione;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class EvocazionePane extends StackPane {
    private final int sSize = 100;
    private final int borderSize = 10;


    private Rectangle rectSfondo = new Rectangle(sSize, sSize);
    private Rectangle rectCenter = new Rectangle(sSize - borderSize, sSize - borderSize);

    private Evocazione ev;

    public EvocazionePane(Evocazione p){
        this.ev = p;
        this.rectSfondo.setFill(ev.getBorderColor());
        this.rectCenter.setFill(this.ev.getEnergyType().getColor());
        this.getChildren().add(rectSfondo);
        this.getChildren().add(rectCenter);

        Text line = new Text(ev.getFirstLine() + "\n" + ev.getSecondLine() + "\n" + ev.getThirdLine() + "\n" + ev.getFourthLine());
        this.getChildren().add(line);
    }

    public Evocazione getEvocazione(){
        return this.ev;
    }
}
