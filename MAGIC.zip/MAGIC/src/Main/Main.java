package Main;

import Main.model.Giocatore;
import Main.model.energies.*;
import Main.model.summons.Evocazione;
import Main.model.summons.EvocazioneBase;
import Main.model.summons.EvocazioneSuprema;
import Main.model.summons.concrete.*;
import Main.view.MainView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.ArrayList;

public class Main extends Application {
    public void start(Stage primaryStage) throws Exception{

        EvocazioneBase ifrit = new Ifrit();
        EvocazioneSuprema phoenix = new Phoenix();
        EvocazioneBase diablos = new Diablos();

        ArrayList<Evocazione> player1Evocazioni = new ArrayList<>();
        player1Evocazioni.add(ifrit);
        player1Evocazioni.add(phoenix);
        player1Evocazioni.add(diablos);
        ArrayList<Energy> player1Energy = new ArrayList<>();
        player1Energy.add(new EnergyFuoco());
        player1Energy.add(new EnergyFuoco());
        player1Energy.add(new EnergyNeutra());
        player1Energy.add(new EnergyNeutra());
        player1Energy.add(new EnergyTenebra());
        Giocatore player1 = new Giocatore(1, player1Evocazioni, player1Energy);


        EvocazioneBase leviathan = new Leviathan();
        EvocazioneSuprema bahamut = new Bahamut();
        EvocazioneBase alexander = new Alexander();
        ArrayList<Evocazione> player2Evocazioni = new ArrayList<>();
        player2Evocazioni.add(leviathan);
        player2Evocazioni.add(bahamut);
        player2Evocazioni.add(alexander);
        ArrayList<Energy> player2Energy = new ArrayList<>();
        player2Energy.add(new EnergyAcqua());
        player2Energy.add(new EnergyAcqua());
        player2Energy.add(new EnergyNeutra());
        player2Energy.add(new EnergyTenebra());
        Giocatore player2 = new Giocatore(2, player2Evocazioni, player2Energy);


        player1.setPlayer2(player2);
        player2.setPlayer2(player1);

        MainView mv = new MainView(player1, player2);

        primaryStage.setTitle("Evocazioni Palle");
        Scene s = new Scene(mv, 400, 400);
        primaryStage.setScene(s);
        primaryStage.show();
    }

    public static void main(String[] args){
        launch(args);
    }
}
