package Main.model;

import Main.model.energies.Energy;
import Main.model.exceptions.GameOverException;
import Main.model.exceptions.IncompatibleTypeException;
import Main.model.exceptions.WrongEnergiesException;
import Main.model.summons.Evocazione;

import java.util.ArrayList;

public class Giocatore {
    private int id;
    private Giocatore player2;
    private ArrayList<Evocazione> evocazioni;
    private ArrayList<Energy> energie;

    public Giocatore(int i, ArrayList<Evocazione> ev, ArrayList<Energy> ener){
        this.id = i;
        this.evocazioni = ev;
        this.energie = ener;
    }

    public void setPlayer2(Giocatore player2) {
        this.player2 = player2;
    }

    public ArrayList<Energy> getEnergie(){
        return this.energie;
    }
    public ArrayList<Evocazione> getEvocazioni() {
        return evocazioni;
    }

    public Evocazione getCurrentEvocazione(){
        return this.evocazioni.get(0);
    }

    public void assegnaEnergia(int i) throws IncompatibleTypeException{
        Energy e = this.energie.remove(i);

        try{
            this.getCurrentEvocazione().assignEnergy(e);
        }
        catch (IncompatibleTypeException ex){
            this.energie.add(e);
            throw new IncompatibleTypeException();
        }
    }

    public void attack() throws WrongEnergiesException, GameOverException{
        this.getCurrentEvocazione().attack(player2.getEvocazioni());
        try {
            player2.checkMorte();
        }
        catch (GameOverException e){
            throw e;
        }
    }

    public void checkMorte() throws GameOverException{
        for(int i = 0; i < this.evocazioni.size(); i++){
            Evocazione e = this.evocazioni.get(i);
            if(e.isDead()){
                this.removeEvocazione(e);
            }
        }
    }

    private void removeEvocazione(Evocazione e) throws GameOverException {
        this.evocazioni.remove(e);
        if(this.hasLost()){
            throw new GameOverException();
        }
    }

    private boolean hasLost(){
        return this.evocazioni.size()==0;
    }
}
