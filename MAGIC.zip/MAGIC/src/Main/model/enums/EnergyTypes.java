package Main.model.enums;

public enum EnergyTypes {
    Acqua,
    Fuoco,
    Tenebra,
    Neutra
}
