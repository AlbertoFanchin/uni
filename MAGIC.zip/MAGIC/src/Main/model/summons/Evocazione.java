package Main.model.summons;

import Main.model.energies.Energy;
import Main.model.exceptions.IncompatibleTypeException;
import Main.model.exceptions.WrongEnergiesException;
import javafx.scene.paint.Color;

import java.util.ArrayList;

public interface Evocazione {
    void attack(ArrayList<Evocazione> target) throws WrongEnergiesException;
    void applyDamage(int d);
    Energy getEnergyType();
    ArrayList<Energy> getAllEnergies();
    boolean isDead();
    void assignEnergy(Energy e) throws IncompatibleTypeException;

    Color getBorderColor();
    String getFirstLine();
    String getSecondLine();
    String getThirdLine();
    String getFourthLine();
}
