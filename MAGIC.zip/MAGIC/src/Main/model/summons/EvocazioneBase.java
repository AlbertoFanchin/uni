package Main.model.summons;

import Main.model.energies.Energy;
import Main.model.enums.EnergyTypes;
import Main.model.exceptions.IncompatibleTypeException;
import Main.model.exceptions.WrongEnergiesException;
import javafx.scene.paint.Color;

import java.util.ArrayList;

public class EvocazioneBase implements Evocazione {
    protected String name;
    protected int pvMax;
    protected int pvAttuali;
    protected Energy type;
    protected Attack att;
    protected ArrayList<Energy> assignedEnergies;

    public EvocazioneBase(String n, int pMax, Energy t, Attack a) throws IncompatibleTypeException {
        this.name = n;
        this.pvMax = pMax;
        this.type = t;
        this.att = a;

        if(!(a.getEnergy().equals(this.type))){
            throw new IncompatibleTypeException();
        }

        this.att.setEv(this);
        this.assignedEnergies = new ArrayList<>();
    }

    @Override
    public void attack(ArrayList<Evocazione> target) throws WrongEnergiesException {
        this.attack(target.get(0));
    }

    protected void attack(Evocazione t) throws WrongEnergiesException {
        this.att.applyTo(t);
    }

    @Override
    public void applyDamage(int d) {
        this.pvAttuali -= d;
    }

    @Override
    public Energy getEnergyType() {
        return this.type;
    }

    @Override
    public ArrayList<Energy> getAllEnergies() {
        return this.assignedEnergies;
    }

    @Override
    public boolean isDead() {
        return this.pvAttuali <= 0;
    }

    @Override
    public void assignEnergy(Energy e) throws IncompatibleTypeException {
        if(!e.equals(this.type)){
            throw new IncompatibleTypeException();
        }
        this.assignedEnergies.add(e);
    }

    @Override
    public Color getBorderColor() {
        return this.type.getColor();
    }

    @Override
    public String getFirstLine() {
        return this.name;
    }

    @Override
    public String getSecondLine() {
        return this.pvAttuali + "/" + this.pvMax + " PV";
    }

    @Override
    public String getThirdLine() {
        return "Energie: " + this.assignedEnergies.size();
    }

    @Override
    public String getFourthLine() {
        return this.att.getDescription() + " " + this.getTargets();
    }

    protected String getTargets(){
        return "";
    }
}
