package Main.model.energies;

import Main.model.enums.EnergyTypes;
import javafx.scene.paint.Color;

public interface Energy {
    EnergyTypes getType();
    boolean isEffective(Energy e);

    Color getColor();

}
