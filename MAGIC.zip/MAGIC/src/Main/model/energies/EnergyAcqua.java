package Main.model.energies;

import Main.model.enums.EnergyTypes;
import javafx.scene.paint.Color;

public class EnergyAcqua extends AbstractEnergy{
    public EnergyAcqua(){
        super(EnergyTypes.Acqua);
    }

    public boolean isEffective(Energy e){
        if(e.getType() == EnergyTypes.Fuoco){
            return true;
        }
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if(o == null){
            return false;
        }
        return (o instanceof Energy);
    }

    @Override
    public Color getColor() {
        return Color.AQUAMARINE;
    }
}
