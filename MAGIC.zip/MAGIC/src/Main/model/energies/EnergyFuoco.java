package Main.model.energies;

import Main.model.enums.EnergyTypes;
import javafx.scene.paint.Color;

public class EnergyFuoco extends AbstractEnergy{
    public EnergyFuoco(){
        super(EnergyTypes.Fuoco);
    }

    public boolean isEffective(Energy e){
        if(e.getType() == EnergyTypes.Acqua){
            return false;
        }
        return true;
    }

    @Override
    public boolean equals(Object o) {
        if(o == null){
            return false;
        }
        return (o instanceof Energy);
    }

    @Override
    public Color getColor() {
        return Color.FIREBRICK;
    }
}
