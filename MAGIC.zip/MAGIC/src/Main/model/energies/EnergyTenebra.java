package Main.model.energies;

import Main.model.enums.EnergyTypes;
import javafx.scene.paint.Color;

public class EnergyTenebra extends AbstractEnergy{
    public EnergyTenebra(){
        super(EnergyTypes.Tenebra);
    }

    public boolean isEffective(Energy e){
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if(o == null){
            return false;
        }
        return (o instanceof Energy);
    }

    @Override
    public Color getColor() {
        return Color.DARKVIOLET;
    }
}
