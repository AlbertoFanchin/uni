package Main.model.exceptions;

public class GameOverException  extends Exception{
    public GameOverException(){}
}
