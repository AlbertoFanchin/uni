package Main.model.exceptions;

public class IncompatibleTypeException extends Exception {
    public IncompatibleTypeException(){}
}
