package Main.model.exceptions;

public class WrongEnergiesException extends Exception{
    public WrongEnergiesException(){};
}
