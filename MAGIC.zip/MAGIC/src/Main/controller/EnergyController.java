package Main.controller;

import Main.model.Giocatore;
import Main.model.exceptions.IncompatibleTypeException;
import Main.view.EnergyPane;
import Main.view.MainView;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;

public class EnergyController implements EventHandler<MouseEvent> {
    private EnergyPane ep;
    private Giocatore g;
    private MainView mv;

    public EnergyController(EnergyPane e, Giocatore p, MainView m){
        this.ep = e;
        this.g = p;
        this.mv = m;
    }

    public void handle(MouseEvent keyEvent){
        if(mv.isP1(this.g)){
            if(keyEvent.getEventType() == MouseEvent.MOUSE_CLICKED){
                try{
                    g.assegnaEnergia(ep.getEnergia());
                }
                catch (IncompatibleTypeException e){
                    Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setContentText("Errore, Energie non compatibili");
                    a.show();
                }

                mv.refresh();
            }
        }
        else {
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText("Giocatore Sbagliato");
            a.show();
        }
    }
}
