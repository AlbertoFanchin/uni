package Main.controller;

import Main.model.Giocatore;
import Main.model.exceptions.GameOverException;
import Main.model.exceptions.WrongEnergiesException;
import Main.view.EvocazionePane;
import Main.view.MainView;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;

public class EvocazioneController implements EventHandler<MouseEvent> {
    private EvocazionePane ep;
    private Giocatore g;
    private MainView mv;

    public EvocazioneController(EvocazionePane e, Giocatore p, MainView m){
        this.ep = e;
        this.g = p;
        this.mv = m;
    }

    public void handle(MouseEvent mouseEvent){
        if(mv.isP1(this.g)){
            if(g.getCurrentEvocazione() == this.ep.getEvocazione()){
                try {
                    this.g.attack();
                    mv.flipPlayers();
                    mv.refresh();
                } catch (WrongEnergiesException e) {
                    Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setContentText("Energie Errate");
                    a.show();
                } catch (GameOverException e) {
                    Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setContentText("Partita finita");
                    a.showAndWait();
                    System.exit(1);
                }
            }
            else{
                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setContentText("Evocazione Errata");
                a.show();
            }
        }
        else{
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setContentText("Giocatore Errato");
            a.show();
        }
    }
}
